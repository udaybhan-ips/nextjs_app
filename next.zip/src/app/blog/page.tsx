export default function Blog() {
    return (
     <div>
      <h4>This is the Blog page!!</h4>
     </div>
    );
  }
  