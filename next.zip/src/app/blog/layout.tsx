import { ReactNode } from "react";

export default function Blog({children,}:{children:ReactNode}) {
    return (
     <div>
      <h3>This is the blog layout!!</h3>
        {children}
     </div>
    );
  }
  