export default function SinglePostPage() {
    return (
     <div>
      <h4>This is the SinglePostPage page!!</h4>
     </div>
    );
  }
  