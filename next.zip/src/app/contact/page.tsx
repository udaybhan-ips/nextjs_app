export default function Contact() {
    return (
     <div>
      <h4>This is the Contact page!!</h4>
     </div>
    );
  }
  